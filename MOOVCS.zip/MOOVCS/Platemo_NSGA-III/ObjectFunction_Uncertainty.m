function obj = ObjectFunction(X)
col=size(X,1);
obj = zeros(col,3);
load('swkr.mat');
load('inflow_random_withoutrelate.mat');
load('error.mat');
num_scenarios = 100; % 100����ˮ��ɳ����
Q_out = zeros(col, 12, num_scenarios); % С�˵׳�������
v = zeros(col, 13, num_scenarios); % С�˵׿��ݱ仯����
%��ʼˮλ,�趨ΪѴ��ˮλ,m
v(:, 1, :) = interp1(kr_zs, kr_v, 230);
z_down = zeros(col, 12, num_scenarios); % С�˵�����վˮλ�仯����
z = zeros(col, 13, num_scenarios); % С�˵�ˮ��ˮλ�仯����
z(:, 1, :) = 230;
sed_rate = zeros(col, 12, num_scenarios); % С�˵���ɳ�ȱ仯����
Q_down = zeros(col, 12, num_scenarios); % С�˵�ˮ���ܳ�������
S_out = zeros(col, 12, num_scenarios); % С�˵�ˮ�������ɳ��
E = zeros(col, 12, num_scenarios); % С�˵�ˮ�ⷢ����
W_down = zeros(col, 12, num_scenarios); % ���κӵ��ٻ�
W_xld = zeros(col, 12, num_scenarios); % ˮ���ٻ�
%�������ʼ��Ⱥ�����Ŀ�꺯��ֵ    
%���Կ���  ��Ⱥ�����Լ�Ŀ�꺯��ֵĬ�ϰ���ÿһ��  �������м���
 
for scenario = 1:num_scenarios
    for ii = 1:col
        for j=1:12           
            z(ii, j + 1, scenario) = X(ii, j);
            v(ii, j + 1, scenario) = interp1(kr_zs, kr_v, X(ii, j))*(1+er1(scenario,1));
            temp = (v(ii, j + 1, scenario) - v(ii, j, scenario)) / 2592000;
            if v(ii, j + 1, scenario) > v(ii, j, scenario)                
                if tgrunoff(scenario, j) - temp < 0 && tgrunoff(scenario, j) > 500
                    Q_out(ii, j, scenario) = 500;
                    v(ii, j + 1, scenario) = v(ii, j, scenario) + (tgrunoff(scenario, j) - Q_out(ii, j, scenario)) * 30 * 24 * 60 * 60;
                    z(ii, j + 1, scenario) = interp1(kr_v, kr_zs, v(ii, j + 1, scenario));%*(1+er1(scenario,1)) 
                elseif tgrunoff(scenario, j) - temp < 0 && tgrunoff(scenario, j) < 500
                    Q_out(ii, j, scenario) = tgrunoff(scenario, j);
                    v(ii, j + 1, scenario) = v(ii, j, scenario);
                    z(ii, j + 1, scenario) = interp1(kr_v, kr_zs, v(ii, j + 1, scenario));%*(1+er1(scenario,1))                    
                elseif tgrunoff(scenario, j) - temp > 500
                    Q_out(ii, j, scenario) = tgrunoff(scenario, j) - temp;
                    v(ii, j + 1, scenario) = v(ii, j, scenario) + (tgrunoff(scenario, j) - Q_out(ii, j, scenario)) * 30 * 24 * 60 * 60;
                    z(ii, j + 1, scenario) = interp1(kr_v, kr_zs, v(ii, j + 1, scenario));%*(1+er1(scenario,1))                    
                else 
                    Q_out(ii, j, scenario) = 500;
                    v(ii, j + 1, scenario) = v(ii, j, scenario) + (tgrunoff(scenario, j) - Q_out(ii, j, scenario)) * 30 * 24 * 60 * 60;
                    z(ii, j + 1, scenario) = interp1(kr_v, kr_zs, v(ii, j + 1, scenario));%*(1+er1(scenario,1))                    
                end                            
            else
                Q_out(ii, j, scenario) = tgrunoff(scenario, j) - temp;                
            end
       
            Q_down(ii, j, scenario) = Q_out(ii, j, scenario) + hsgrunoff(scenario, j) + wzrunoff(scenario, j);
            z_down(ii, j, scenario) = 133.3; % 0.0007*(Q_out(ii,j,scenario))+

            %a = log10(((v(ii,j)+v(ii,j+1))/2)/(Q_out(ii,j)*10000));%+X(ii,j+31)+X(ii,j+31)
            a = (tgrunoff(scenario, j) * 0.02678)^0.1;
            b = (0.5 * (v(ii, j, scenario) + v(ii, j + 1, scenario)) / (86400 * Q_out(ii, j, scenario)))^-0.8;
            %sed_rate(ii,j) =-0.5 * a + 1.8;%W_Q*(v_average/qout_average)^-0.8
            sed_rate(ii, j, scenario) = 2.17 * a * b*(1+er2(scenario,1));%
            if sed_rate(ii, j, scenario) < 0
                    sed_rate(ii, j, scenario) = 0.1;
            end        

            S_out(ii, j, scenario) = sed_rate(ii, j, scenario) * tgsed(scenario, j);

            E(ii, j, scenario) = 0.9 * 9.8 * Q_out(ii, j, scenario) * ((z(ii, j + 1, scenario) + z(ii, j, scenario)) / 2 - z_down(ii, j, scenario));
            %W_down(1,j) = 86.4*Q_down(1,j)*SSC_out(1,j)*(1- S_Arate(1,j));%86.4*Q_down(1,j)^2*(SSC_out(1,j)/Q_down(1,j)-0.126*((SSC_out(1,j)/Q_down(1,j))^0.5));
            W_xld(ii, j, scenario) = (tgsed(scenario, j) - S_out(ii, j, scenario)) * 31 * 24 * 60 * 60;
            W_down(ii, j, scenario) = ((0.0447 * S_out(ii, j, scenario) - 1.933e-7 * Q_down(ii, j, scenario)^2.07) / 12)*(1+er3(scenario,1));
            %W_down(ii, j) = 86.4*(Q_down(ii, j) ^ 2.07)*(S_out(ii, j)/Q_down(ii, j)-0.108*(S_out(ii, j)/Q_down(ii, j))^0.47);
        end    
    end
end
for ii = 1:col
    W_xld_sum_month = sum(W_xld(ii, :, :), 2); % �ȶԲ�ͬ�·����
    W_xld_sum_scenario = sum(W_xld_sum_month, 3); % �ٶԲ�ͬ�������
    obj(ii, 1) = mean(W_xld_sum_scenario)/num_scenarios; % ˮ���ٻ�����ֵ��С

    W_down_sum_month = sum(W_down(ii, :, :), 2); % �ȶԲ�ͬ�·����
    W_down_sum_scenario = sum(W_down_sum_month, 3); % �ٶԲ�ͬ�������
    obj(ii, 2) = (W_down_sum_scenario)/num_scenarios; % ���κӵ��ٻ���ֵ��С

    E_sum_month = sum(E(ii, :, :), 2); % �ȶԲ�ͬ�·����
    E_sum_scenario = sum(E_sum_month, 3); % �ٶԲ�ͬ�������
    obj(ii, 3) = (-mean(E_sum_scenario) * 31 * 24)/num_scenarios; % ��������ֵ���
end




