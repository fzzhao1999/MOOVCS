rm(list = ls())
library(VineCopula)
library(copula)
library(readxl)

# 导入边缘分布
cdfdata_origin <- read_xlsx("D:/大论文/第四章调度/抽样/预报不确定性/考虑时间/月尺度/CDF序列.xlsx")
cdfdata <- cdfdata_origin[2:nrow(cdfdata_origin), 2:ncol(cdfdata_origin)]
columns <- c()    # 列名
for (i in 1:12){
  columns[i] <- paste('潼关.径流.', as.character(i), '月', sep = "")
  columns[12+i] <- paste('潼关.泥沙.', as.character(i), '月', sep = "")
  columns[24+i] <- paste('黑石关.径流.', as.character(i), '月', sep = "")
  columns[36+i] <- paste('武陟.径流.', as.character(i), '月', sep = "")
}
colnames(cdfdata) <- columns
rm(i, cdfdata_origin, columns)
cdfdata <- sapply(cdfdata, as.numeric)    # 将数据框里的内容转成数值型变量

# 直接拟合一个48维的 Vine Copula 函数
Rst <- RVineStructureSelect(cdfdata, family = c(3:5), selectioncrit = "AIC", 
                            progress = FALSE, se = TRUE, method = 'mle', rotations = TRUE)

# 拟合检验
KStest <- RVineGofTest(cdfdata, Rst, method = "ECP2", statistic = "KS")

#fit_t_copula <- function(data) {
#  data <- as.matrix(data)  # 确保数据为矩阵
  # 初始化参数
#  start <- c(rep(0.5, ncol(data) * (ncol(data) - 1) / 2), 4)  # 设置初始值
  # 估计参数
#  fit <- tryCatch({
#    fitCopula(tCopula(dim = ncol(data), df = 4, dispstr = "un"), data, method = "ml", start = start, optim.method = "Nelder-Mead")
#  }, error = function(e) {
#    cat("Error in fitCopula: ", e$message, "\n")
#    return(NULL)
#  })
#  return(fit)
#}



#t_copula_fit <- fit_t_copula(cdfdata)



#--------------------生成多组服从U[0,1]的随机数--------------------

#拉丁超立方抽样 εCDF=εCDF_fixed+εCDF_rand
#εCDF_fixed是固定项，与抽样次数有关, εCDF_fixed=0,1/H,2/H,...,(H-1)/H
#εCDF_rand是随机项，是在0和1/H之间的随机数

sample_size <- 100    # 抽样次数H

# 生成48维的随机数的随机项
random_number_rand <- list()
for (j in 1:48){
  set.seed(j)
  random_number_rand[[j]] <- runif(sample_size, min = 0, max = 1/sample_size)
}

# 基于 εCDF=εCDF_fixed+εCDF_rand, 得到真正的服从 U[0,1] 的随机数
random_number_seq <- random_number_rand
for (j in 1:48){
  for (h in 1:sample_size){
    random_number_seq[[j]][h] <- random_number_seq[[j]][h] + (h-1)/sample_size
  }
}

# 打乱顺序
random_number_disorder <- list()
for (j in 1:48){
  set.seed(100+j)
  random_number_disorder[[j]] <- sample(random_number_seq[[j]])
}

# 变形成矩阵
random_number <- matrix(0, nrow=sample_size, ncol=48)
for (j in 1:48){
  random_number[,j] <- random_number_disorder[[j]]
}


#------------------------------抽样------------------------------

# 基于拟合的48维 Vine Copula 和生成的随机数抽样
sim_cdfdata <- RVineSim(sample_size, Rst, U = random_number)
#sim_cdfdata <- rCopula(sample_size, t_copula_fit@copula)
# 转换成数据框（如果需要）
sim_cdfdata <- data.frame(sim_cdfdata)
write.csv(sim_cdfdata, file="D:/大论文/第四章调度/抽样/预报不确定性/考虑时间/月尺度/sim_cdf_tcopula10011.csv")
